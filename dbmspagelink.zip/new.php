<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
    <link rel="stylesheet" href="login.html">
    <style>
      #for{
        display: flex;
        flex-direction: column;
        justify-content: center;
        align-items: center;
        padding:1rem;
       
        
      }
      input{
        width:22rem;
        height:2rem;
        margin:1rem;
        text-align: center;
        font-weight:bold;
      }
      h1{
        text-align: center;
        color:green;
        
       
      }
      #sub{
        background-color: rgb(98, 98, 160);
        cursor: pointer;
        font-weight: bold;
      }
      
    </style>
</head>
<body>
    <h1>Registration</h1>
    <form action="#" method="post" id="for">
       Name <input type="text" name="user" placeholder="Enter your name" >
      Email <input type="text" name="email" placeholder="Enter your email">
      Address<input type="text" name="Add" placeholder="Enter your address">
      Password<input type="password" name="pass" placeholder="Enter your password">
      <input type="submit"  name="submit" id="sub">
      <p>have an account?<a href="login.html">login</a></p>
   </form>

   <?php
    if(isset($_POST['submit'])){

    
     $username=$_POST['user'];
     $email=$_POST['email'];
     $address=$_POST['Add'];
     $pass=$_POST['pass'];

     $hostname='localhost';
     $user='root';
     $pass='';
     $dbname='regis';

     
     $conn=mysqli_connect($hostname,$user,$pass,$dbname);
    //  $sql=$sql="CREATE DATABASE AMAN";
     $sql="INSERT INTO student(name,email,address,password) values ('$username','$email','$address','$pass')";
     mysqli_query($conn,$sql);
    }
     
   ?>
   
</body>
</html>